﻿using Microsoft.EntityFrameworkCore;
using Task02MVC.Data.DbContexts;

namespace Task02MVC.Models
{
    public class DepartmentBL
    {
        // Open connection with DB
        SchoolDbContext context = new SchoolDbContext();

        // ShowAll: كل الأقسام
        public List<Department> GetAll()
        {
            return context.Departments.ToList();
        }

        // ShowDetails: قسم واحد بالـ id (ومعاه الطلاب)
        public Department? GetById(int id)
        {
            return context.Departments
                .Include(D => D.Students)
                .FirstOrDefault(D => D.Id == id);
        }

        // Add: إضافة قسم جديد
        public void AddDept(Department dept)
        {
            context.Departments.Add(dept);   // save to memory
            context.SaveChanges();           // save to DB (الـ INSERT الفعلي)
        }


        // الاسم موجود قبل كده؟ (excludeId عشان في الـ Edit منقارنش القسم بنفسه)
        public bool NameExists(string name, int? excludeId = null)
        {
            return context.Departments.Any(D => D.Name == name && (excludeId == null || D.Id != excludeId));
        }

        // Edit: الأوبجكت المتتبَّع اتعدل في الـ Controller، فكفاية SaveChanges
        public void SaveInDB()
        {
            context.SaveChanges();
        }
    }
}
