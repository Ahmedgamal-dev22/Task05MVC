﻿namespace Task02MVC.Models
{
    public class StuCrsRes
    {
        // Composite PK (هنعرفه في الـ Configuration)
        public int StudentId { get; set; }
        public int CourseId { get; set; }

        public int Grade { get; set; }

        public Student? Student { get; set; }
        public Course? Course { get; set; }
    }
}
