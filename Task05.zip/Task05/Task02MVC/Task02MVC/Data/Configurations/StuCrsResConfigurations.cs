﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Task02MVC.Models;

namespace Task02MVC.Data.NewFolder
{
    public class StuCrsResConfigurations : IEntityTypeConfiguration<StuCrsRes>
    {
        public void Configure(EntityTypeBuilder<StuCrsRes> builder)
        {
            builder.ToTable("StuCrsRes");

            // Composite PK
            builder.HasKey(X => new { X.StudentId, X.CourseId });

            builder.HasOne(X => X.Student)
                   .WithMany(S => S.StuCrsResults)
                   .HasForeignKey(X => X.StudentId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(X => X.Course)
                   .WithMany(C => C.StuCrsResults)
                   .HasForeignKey(X => X.CourseId)
                   .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
