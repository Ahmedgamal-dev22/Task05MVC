﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Task02MVC.Models;

namespace Task02MVC.Data.NewFolder
{
    public class DepartmentConfigurations : IEntityTypeConfiguration<Department>
    {
        public void Configure(EntityTypeBuilder<Department> builder)
        {
            builder.ToTable("Departments");

            builder.HasKey(D => D.Id);

            builder.Property(D => D.Name).HasMaxLength(50);
            builder.Property(D => D.MgrName).HasMaxLength(50);
        }
    }
}
