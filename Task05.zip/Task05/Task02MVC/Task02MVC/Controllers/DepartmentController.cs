﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Task02MVC.ViewModels;
using Task02MVC.Models;
using Task02MVC.ViewModels;


namespace Task02MVC.Controllers
{
    public class DepartmentController : Controller
    {
        DepartmentBL departmentBL = new DepartmentBL();

        // Req URL: /Department/ShowAll
        public IActionResult ShowAll()
        {
            List<Department> depts = departmentBL.GetAll();
            return View("ShowAll", depts);
        }

        // Req URL: /Department/ShowDetails?id=1
        public IActionResult ShowDetails(int id)
        {
            Department? dept = departmentBL.GetById(id);

            if (dept == null)
                return NotFound();

            return View("ShowDetails", dept);
        }



        // Req URL: /Department/ShowDetailsVM?id=1
        public IActionResult ShowDetailsVM(int id)
        {
            // 1) Resources: جيب الداتا من الـ BL
            Department? dept = departmentBL.GetById(id);

            if (dept == null)
                return NotFound();

            // 2) Mapping: انقل الداتا للـ ViewModel
            DeptWithStudentsViewModel VM = new DeptWithStudentsViewModel();
            VM.DeptName = dept.Name;

            VM.StudentNames = dept.Students?
                .Where(S => S.Age > 25)
                .Select(S => S.Name)
                .ToList() ?? new List<string>();

            int studentsCount = dept.Students?.Count ?? 0;
            VM.DeptState = studentsCount > 50 ? "Main" : "Branch";

            // 3) ابعته للـ View
            return View("ShowDetailsVM", VM);
        }

        // ============ Add ============
        // GET: /Department/Add
        [HttpGet]
        public IActionResult Add()
        {   
            return View("Add", new DepartmentFormViewModel());
        }

        // POST: /Department/SaveAdd
        [HttpPost]
        public IActionResult SaveAdd(DepartmentFormViewModel vm)
        {
            // Business rule: الاسم ميتكررش
            if (!string.IsNullOrWhiteSpace(vm.Name) && departmentBL.NameExists(vm.Name))
                ModelState.AddModelError(nameof(vm.Name), "This department name already exists");

            if (ModelState.IsValid)
            {
                try
                {
                    // Mapping: ViewModel -> Model
                    Department dept = new Department();
                    dept.Name = vm.Name;
                    dept.MgrName = vm.MgrName;

                    departmentBL.AddDept(dept);
                    return RedirectToAction(nameof(ShowAll));
                }
                catch (DbUpdateException)
                {
                    ModelState.AddModelError("", "Could not save the department. Please try again.");
                }
            }

            return View("Add", vm);
        }

        // ============ Edit ============
        // GET: /Department/Edit/3
        [HttpGet]
        public IActionResult Edit(int id)
        {
            Department? dept = departmentBL.GetById(id);
            if (dept == null)
                return NotFound();

            // Mapping: Model -> ViewModel
            DepartmentFormViewModel vm = new DepartmentFormViewModel();
            vm.Id = dept.Id;
            vm.Name = dept.Name;
            vm.MgrName = dept.MgrName;

            return View("Edit", vm);
        }

        // POST: /Department/SaveEdit
        [HttpPost]
        public IActionResult SaveEdit(DepartmentFormViewModel vm)
        {
            if (!string.IsNullOrWhiteSpace(vm.Name) && departmentBL.NameExists(vm.Name, vm.Id))
                ModelState.AddModelError(nameof(vm.Name), "This department name already exists");

            if (ModelState.IsValid)
            {
                Department? oldDept = departmentBL.GetById(vm.Id);
                if (oldDept == null)
                    return NotFound();

                try
                {
                    // Update الأصل المتتبَّع
                    oldDept.Name = vm.Name;
                    oldDept.MgrName = vm.MgrName;

                    departmentBL.SaveInDB();
                    return RedirectToAction(nameof(ShowAll));
                }
                catch (DbUpdateException)
                {
                    ModelState.AddModelError("", "Could not update the department. Please try again.");
                }
            }

            return View("Edit", vm);
        }
    }
}
