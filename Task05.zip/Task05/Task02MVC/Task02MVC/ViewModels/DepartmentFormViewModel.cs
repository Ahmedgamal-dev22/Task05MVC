﻿using System.ComponentModel.DataAnnotations;

namespace Task02MVC.ViewModels
{
    public class DepartmentFormViewModel    
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Department name is required")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Name must be between 3 and 50 characters")]
        [Display(Name = "Department Name")]
        public string Name { get; set; } = null!;

        [StringLength(50, ErrorMessage = "Manager name must be less than 50 characters")]
        [RegularExpression(@"^[a-zA-Z\s]*$", ErrorMessage = "Manager name must contain letters and spaces only")]
        [Display(Name = "Manager Name")]
        public string? MgrName { get; set; }
    }
}