﻿using System.ComponentModel.DataAnnotations;
using Task02MVC.Models;

namespace Task02MVC.ViewModels
{
    public class StudentFormViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100)]
        public string Name { get; set; } = null!;

        [Range(15, 80, ErrorMessage = "Age must be between 15 and 80")]
        public int Age { get; set; }

        [Display(Name = "Department")]
        [Required(ErrorMessage = "Please select a department")]
        public int? DepartmentId { get; set; }

        // لل Dropdown
        public List<Department> DeptList { get; set; } = new List<Department>();
    }
}
